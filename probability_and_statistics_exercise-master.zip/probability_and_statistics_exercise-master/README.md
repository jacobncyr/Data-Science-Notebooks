# Exercises for Probability and Statistics

We have 3 files in the repository:

- MontyHall Challenge
- Exercises for hypothesis testing
- Exercises for CLT

